<?php
session_destroy();
echo "Username/password combination not in system.<p>";
echo '<a href = "StoreFront.php">Go back to main page</a><br>';



 ?>