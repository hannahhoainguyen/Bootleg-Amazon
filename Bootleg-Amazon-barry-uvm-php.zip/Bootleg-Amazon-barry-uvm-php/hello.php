<html>
 <head>
  <title>PHP Test</title>
  	<!-- <link rel="stylesheet" type="text/css" media="screen" href="style.css" /> -->
 </head>
 <body>
 <?php echo '<p><h1>Rockingham Random-Salt Repo</h1></p>'; ?>

<?php
echo "
  <table border='1'>
   <tr>
    <th>Item</th>
    <th>Cost</th>
    <th>Items in Stock</th>
    <th>Detail</th>
   </tr>
   <tr>
    <td>Headphones</td>
    <td>$1000.00</td>
    <td>3</td>
    <td><a href=\"headphones.html\">Detail</a></td>
   </tr>
   <tr>
    <td>Snowshoes</td>
    <td>$3000.00</td>
    <td>10</td>
    <td><a href=\"snowshoes.html\">Detail</a></td>
   </tr>
   <tr>
    <td>Surfboard</td>
    <td>$9000.00</td>
    <td>25</td>
    <td><a href=\"surfboard.html\">Detail</a></td>
   </tr>
   <tr>
    <td>Narsil - Sword of Elendil</td>
    <td>$900000000000.00</td>
    <td>1</td>
    <td><a href=\"narsil.html\">Detail</a></td>
   </tr>
  </table>";

?>





 </body>
</html>
