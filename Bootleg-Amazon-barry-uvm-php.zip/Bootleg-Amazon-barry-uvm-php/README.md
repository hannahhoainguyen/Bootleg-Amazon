# CS205-online-store
*Jared Carlson, Chris Erkson, Hannah Nguyen and Barry Smith*

## Online shopping interface with back-end dbase and front-end GUI
The proposed idea for our project is to create an online shopping interface that will contain a back-end database and front-end GUI where a use can scroll through items that contain pictures and prices and add select items to their cart. The cart can then be processed and send a delivery message to the user’s e-mail. We will also be hosting the web app on silk.
Languages:
- CSS
- HTML
- PHP
- Javascript
- SQL
