<?php
session_start();
session_unset();
session_destroy();
echo '<p><a href="StoreFront.php">Back to store</a><p>';


 ?>